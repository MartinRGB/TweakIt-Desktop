import { init } from 'tinyh264';

init();
