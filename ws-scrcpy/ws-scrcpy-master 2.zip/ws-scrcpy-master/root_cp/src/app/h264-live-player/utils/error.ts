export default function error(message: string): void {
    console.error(message);
    console.trace();
}
