export default interface QVHackDeviceDescriptor {
    state: string;
    ProductName: string;
    ProductType: string;
    Udid: string;
    ProductVersion: string;
}
