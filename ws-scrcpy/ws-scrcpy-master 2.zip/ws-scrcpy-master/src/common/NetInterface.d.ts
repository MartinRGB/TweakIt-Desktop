export interface NetInterface {
    name: string;
    ipv4: string;
}
