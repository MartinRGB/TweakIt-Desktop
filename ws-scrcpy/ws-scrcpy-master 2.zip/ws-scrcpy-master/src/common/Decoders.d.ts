export type Decoders = 'broadway' | 'mse' | 'tinyh264';
